import xbmc

if ( __name__ == "__main__" ):
	xbmc.executebuiltin('XBMC.StartAndroidActivity("de.prosiebensat1digital.seventv")')