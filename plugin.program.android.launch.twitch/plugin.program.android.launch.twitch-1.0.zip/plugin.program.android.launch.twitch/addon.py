import xbmc

if ( __name__ == "__main__" ):
	xbmc.executebuiltin('XBMC.StartAndroidActivity("tv.twitch.android.app")')